app.controller("humusSearchCtrl", ['$scope', '$filter', 'humusService',
    function($scope, $filter, humusService){
        $scope.searchInput = "";
        $scope.searchHistory = [];
        $scope.searchResults = [];
        $scope.clickSearch = function(){

            var found = $scope.searchHistory.indexOf($scope.searchInput);
            if( found == -1){
                $scope.searchHistory.push($scope.searchInput);
            }

            humusService.getHumusPlaces(
                function getPlaces(data){
                    console.log("success");
                    $scope.searchResults = $filter('filter')(data.places, 
                        function(item){
                            var name = item.name.toLowerCase();
                            var subStr = $scope.searchInput.toLowerCase();
                            return name.indexOf(subStr) != -1
                        });
                    
    
    
                },
                function error(message){
                    console.log("there was an error");
                }
            );
    
        }
        $scope.clickSearchLink = function(str){
            $scope.searchInput = str;
            humusService.getHumusPlaces(
                function getPlaces(data){
                    console.log("success");
                    $scope.searchResults = $filter('filter')(data.places, 
                        function(item){
                            var name = item.name.toLowerCase();
                            var subStr = $scope.searchInput.toLowerCase();
                            return name.indexOf(subStr) != -1
                        });
                },
                function error(message){
                    console.log("there was an error");
                }
            );

        }
        $scope.openLink = function(link){
            var win = window.open(link, '_blank');
            win.focus()
        }
    }
])